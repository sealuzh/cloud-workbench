# fio-benchmark CHANGELOG

##0.2.0

[Joel Scheuner] - 2014-04-22

* Add more configuration options and refactor generic benchmark related utilities into own benchmark cookbook.

##0.1.0

[Joel Scheuner] - 2014-03 Initial release of fio-benchmark