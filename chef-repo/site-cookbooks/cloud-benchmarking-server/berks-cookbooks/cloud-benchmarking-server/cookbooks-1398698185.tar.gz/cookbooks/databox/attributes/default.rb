default["databox"]["db_root_password"] = nil

# A list of database_user's attribute parameters.
# See database cookbook for details.
default["databox"]["databases"]["mysql"] = []
default["databox"]["databases"]["postgresql"] = []
