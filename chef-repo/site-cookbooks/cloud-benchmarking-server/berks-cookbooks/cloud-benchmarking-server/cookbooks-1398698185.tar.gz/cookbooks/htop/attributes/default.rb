#
# Cookbook Name:: htop
# Attributes:: default
#

default['htop']['version'] = nil
