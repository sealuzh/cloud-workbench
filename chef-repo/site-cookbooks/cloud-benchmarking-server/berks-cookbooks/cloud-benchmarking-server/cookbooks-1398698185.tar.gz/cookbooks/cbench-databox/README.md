# cbench-databox-cookbook

Wrapper cookbook for the databox cookbook from https://github.com/area17/databox-cookbook to fix an error. Pending pull request https://github.com/teohm/databox-cookbook/pull/6 will probably never be merged.

## Supported Platforms

See databox.

## Attributes

See databox

## Usage

### cbench-databox::default

See databox

## License and Authors

Author:: Joel Scheuner (joel.scheuner.dev@gmail.com)
