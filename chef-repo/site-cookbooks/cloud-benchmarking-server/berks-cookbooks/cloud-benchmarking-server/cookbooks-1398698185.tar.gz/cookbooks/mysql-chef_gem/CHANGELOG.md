crossplat CHANGELOG
========================
This file is used to list changes made in each version of the crossplat cookbook.

v0.0.2 (2014-03-31)
-------------------
Initial Release


v0.0.1 (2014-03-28)
-------------------
- Initial release
