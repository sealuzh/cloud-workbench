gem_package "vagrant" do
  action :remove
end

chef_gem "vagrant" do
  action :remove
end
