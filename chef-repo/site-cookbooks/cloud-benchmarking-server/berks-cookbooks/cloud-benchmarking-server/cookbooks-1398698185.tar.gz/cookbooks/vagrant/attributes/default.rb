default['vagrant']['url'] = nil
default['vagrant']['checksum'] = nil
default['vagrant']['plugins'] = []
default['vagrant']['plugins_user'] = "root"
default['vagrant']['plugins_group'] = "root"
default['vagrant']['boxes'] = []
default['vagrant']['msi_version'] = ''
